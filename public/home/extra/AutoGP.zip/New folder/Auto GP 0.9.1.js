//BasicGP v0.9.2
//Written by Mohib "Mr. Uncompetitive" Azam
//Current as of 5/5/17

//TODO: Add JSON support
//TODO: Handle capitalization
//TODO: Add comments to identify misspellings or "cliche phrases"
//TODO: Differentiate between article and analysis

/**
 * CODE
 */

//A constructor for a DictTerm
function DictTerm(words) {
    //words in the term (Array of Strings)
    this.words = words;

    //get the full string of the term
    this.term = function () {
        var temp = "";
        for (var i = 0; i < words.length; i++) {
            temp += words[i];
            if (i < words.length - 1) {
                temp += " ";
            }
        }
        return temp;
    }

    //get the number of words in the DictTerm 
    this.length = function () {
        return this.words.length;
    }
}


//1. Check for a word
//2. Label this as the first word
//3. Check for DictTerms whose first word match the given word
//4. Add all matches to a Dictionary or Map
//5. If there is only one result, enact the replacement
//6. If no matches, add the given word and move on
//7. Go to the next word and label it as the ith word
//8. Check for results in the new Dictonary or Map whose ith word matches this
//9. Repeat until 0 or 1 matches left 

//A constructor for a Map Data Structure with DictTerms
function Map() {

    //Array of all the inputs
    this.input = [];
    //Array of all the outputs
    this.output = [];

    //Add an input and a respective output for the map
    //UNLESS said input already exists

    //TODO: Use a binary searching-esque algorithm to make
    //getOutput and getCloseMatch more efficient.
    //Likely should sort stuff into maps themselves
    //so that we can group more easily...
    this.addDictTerms = function (inadd, outadd) {
        var ind = this.input.indexOf(inadd);
        if (ind == -1) {
            this.input.push(inadd);
            this.output.push(outadd);
        }
    };

    //Get the output associated with the given input

    //TODO: After fixing addDictTerms, implement binary search
    //to make this faster
    this.getOutput = function (inget, wordNum) {
        console.log("forming a map with getOutput");
        var fakeMap = new Map();
        for (var i = 0; i < this.input.length; i++) {
            var currentTerm = this.input[i];
            var word = currentTerm.words[wordNum];
            if (word !== undefined) {
                if (word.toLowerCase() == inget.toLowerCase()) {
                    console.log("adding the term " + currentTerm.term());
                    fakeMap.addDictTerms(this.input[i], this.output[i]);
                }
            }
        }
        console.log("done making map");
        return fakeMap;
    };
    
    //Get the dictTerm with this word (in a given position) as its last word

    //TODO: After fixing addDictTerms, implement binary search
    //to make this faster
    this.getCloseMatch = function (inget, wordNum) {
        console.log("forming a map with getCloseMatch");
        var fakeMap = new Map();
        for (var i = 0; i < this.input.length; i++) {
            var currentTerm = this.input[i];
            var word = currentTerm.words[wordNum];
            if (word !== undefined) {
                if (word.toLowerCase() == inget.toLowerCase() && currentTerm.length == wordNum + 1) {
                    console.log("adding the term " + currentTerm.term());
                    fakeMap.addDictTerms(this.input[i], this.output[i]);
                    break;
                }
            }
        }
        console.log("done making map");
        return fakeMap;
    }

    //Get the length of this map
    this.length = function () {
        return this.input.length;
    }

}

//A constructor for a Model of the app
//containing various fields for storing important text
//and methods for managing them
function Model(initialText, map, addColor, removeColor) {

    this.initialText = initialText;
    this.addColor = addColor;
    this.removeColor = removeColor;
	this.map = map;
    this.finalText = "";

    this.getFinalText = function () {
        return this.finalText;
    };		

    this.makeBbCode = function (oldWord, newWord) {
        var removedWord = "[B][COLOR=" + removeColor + "][S]" + oldWord + "[/S][/COLOR][/B]";
        var addedWord = "[B][COLOR=" + addColor + "]" + newWord + "[/COLOR][/B]";
        return removedWord + " " + addedWord;
    };
    
    this.createFinalText = function (charInd, wordNum, phrase, closeMap, mapToUse) {
        //Initialize the currently stored word to be nothing
        var tempWord = "";
        //Initializes the current state of the phrase as a local variable
        var tempPhrase = phrase;
        //The current char
        var currentChar;
        console.log("initialized variables");
        //Start incrementing through the text
        for (var i = charInd; i < initialText.length; i++) {
            currentChar = this.initialText.charAt(i);
            console.log("got current char. It's a " + currentChar);
            //if the current character is a space, complete the word and handle the result accordingly
            if (currentChar == " ") {
                console.log("moving to handleSpace");
                this.handleSpace(tempWord, i, wordNum, tempPhrase, closeMap, mapToUse, currentChar);
                return;
            }
            //Handling for punctuation...
            //basically the same thing except you only want exact matches...
            else if (currentChar == "." ||
                currentChar == "," ||
                currentChar == ":" ||
                currentChar == ";" ||
                currentChar == "�" ||
                currentChar == "?" ||
                currentChar == "!") {

                console.log("punctuation mark detected");

                //Check if phrase matches something in the map
                
                //We only care about the closest result this time
                var closestMap = mapToUse.getCloseMatch(tempWord, wordNum);

                console.log("moving to closeMatch");

                this.closeMatch(i, currentChar, tempPhrase, closestMap);
                return;
            }

            //Otherwise, add on the character to the current word
            else {
                console.log("accumulating the current word and charcter");
                tempWord += currentChar;
                tempPhrase += currentChar;
            }
        }
        //Handle reaching the end of the text
        if (tempPhrase !== "") {
            var closestMap = mapToUse.getCloseMatch(tempWord, wordNum);
            this.closeMatch(i, "", tempPhrase, closestMap);
        }
    };

    this.handleSpace = function (tempWord, charInd, wordNum, tempPhrase, closeMap, mapToUse, indChar) {
        //Check if word matches something in the map
        console.log("in handleSpace")
        //The terms that match the given word at the wordNum
        var resultingMap = mapToUse.getOutput(tempWord, wordNum);
        //Term whose length also matches the given wordNum
        var closestMap = mapToUse.getCloseMatch(tempWord, wordNum);
        console.log("created the two necessary maps");

        //If there is more than 1 valid result...
        if (resultingMap.length() > 1) {
            //Make a recursive call...probably delete some local variables
            //to prevent stack overflow
            console.log("more than one entry in the map, returning to createFinalText");
            delete tempWord;
            this.createFinalText(charInd + 1, wordNum + 1, tempPhrase + " ", closestMap, mapToUse);
            return;
        }
        //If there are no valid results, check to see if there was a last closest match
        //If so, use that instead
        else if (resultingMap.length() == 0) {
            console.log("no matches, going to closeMatch");
            this.closeMatch(charInd, indChar, tempPhrase, closeMap);
        }
        //If there is one valid result, check to see if it's of a proper length...
        else {
            console.log("one match found");
            if (tempPhrase !== resultingMap.output[0].term()) {
                if (wordNum + 1 == resultingMap.input[0].length) {
                    console.log("making correction");
                    this.finalText += this.makeBbCode(tempPhrase, resultingMap.output[0].term());
                    this.finalText += " ";
                    var newCloseMap = new Map();
                    this.createFinalText(charInd + 1, 0, "", newCloseMap, this.map);
                }
                else {
                    //Make a recursive call...probably delete some local variables
                    //to prevent stack overflow
                    console.log("making recursive call");
                    delete tempWord;
                    this.createFinalText(charInd + 1, wordNum + 1, tempPhrase + " ", closestMap, mapToUse);
                    return;
                }
            }
            else {
                console.log("adding without corections")
                this.finalText += (tempPhrase + " ");
                var newCloseMap = new Map();
                this.createFinalText(charInd + 1, 0, "", newCloseMap, this.map);
            }
        }
    };

    this.closeMatch = function (charInd, currentChar, tempPhrase, closeMap) {
        //Check if the result is the same
        //If so, run the bbcode method
        console.log("in closeMatch");
        if (closeMap.input.length !== 0 && tempPhrase !== closeMap.output[0].term()) {
            console.log("making corection");
            this.finalText += this.makeBbCode(tempPhrase, closeMap.output[0].term());
            this.finalText += currentChar;
            console.log("made correction");
        }
        //if not, add it as is
        else {
            this.finalText += (tempPhrase + currentChar);
            console.log("no correction made");
        }
        var newCloseMap = new Map();
        console.log("returning to createFinalText");
        this.createFinalText(charInd + 1, 0, "", newCloseMap, this.map);
    };
}

/**
 * Main Method
 */

//Run through the intended functionality of the model
//to make the AutoGPer work (should be called by onclick)

//TODO: Rewrite method to support new version of the code
function Operate() {
    //1. Grab the text currently in the input text field
    var initialText = document.getElementById("inputText").value;

    //2. Grab the colors currently selected
    var addColor = document.getElementById("addColor").value;
    var removeColor = document.getElementById("removeColor").value;

    //3. Check the buttons which have been selected so far
    var anaVal = document.getElementById("Analysis");
    var artVal = document.getElementById("Article");

	//4. Initialize dictionaries
	var dict1 = new Dictionary();
	dict1.addToDict("Speed");
	dict1.addToDict("sleep");
	dict1.addToDict("status");
	var dicts = [];
	dicts.push(dict1);

	//5. Initialize Maps
	var map1 = new Map();
    map1.addDictTerms("Ekiller", "Extreme Killer Arceus");
    map1.addDictTerms("ekiller", "Extreme Killer Arceus");
    map1.addDictTerms("EKiller", "Extreme Killer Arceus");
    map1.addDictTerms("max", "maximum");
    map1.addDictTerms("Max", "Maximum");
    map1.addDictTerms("ZHypnosis", "Z-Hypnosis");
    map1.addDictTerms("Luke", "Lucario");
    map1.addDictTerms("Fairyceus", "Arceus-Fairy");
    map1.addDictTerms("rocks", "Stealth Rock");
	var maps =[];
	maps.push(map1);

    //6. Initialize Model
    //var theModel = new Model(initialText, dictionaries, maps, addColor, removeColor);
    var theModel = new Model(initialText, dicts, maps, addColor, removeColor);

    //7. Operate on the Model so that the finalText gets produced
    theModel.createFinalText();

    //8. Obtain the finalText and place it in the output text field
    //NOTE TO SELF: If line breaks aren't showing up, try using <pre> tags
    var finalText = theModel.getFinalText();

    document.getElementById("outputText").value = finalText;
}

/**
 * Tests
 */

//TODO: Rewrite some of these tests
//Some will need to be taken out,
//but most should either need no edits
//or simple adjustments to account for the new Map format

//Basic test for getting the finalText
function getFinalTextTest1(expected) {
    results.total++;
    var testModel = new Model("a", new Map(), "#000000", "#000000");
    var result = testModel.getFinalText();
    if (result !== expected) {
        results.bad++;
        console.log("Expected " + expected +
        ", but was " + result);
    }
}

//Basic empty case for creating the finalText
function createTextTest1(expected) {
    results.total++;
    var testModel = new Model("", new Map(), "#000000", "#000000");
    testModel.createFinalText(0, 0, "", new Map(), testModel.map);
    var result = testModel.getFinalText();
    if (result !== expected) {
        results.bad++;
        console.log("Expected " + expected +
        ", but was " + result);
    }
}

//Test for creating the finalText when we are given some text
function createTextTest2(expected) {
    results.total++;
    var testModel = new Model("a", new Map(), "#000000", "#000000");
    testModel.createFinalText(0, 0, "", new Map(), testModel.map);
    var result = testModel.getFinalText();
    if (result !== expected) {
        results.bad++;
        console.log("Expected " + expected +
        ", but was " + result);
    }
}

//Test for creating the finalText when we are given some text
function createTextTest3(expected) {
    results.total++;
    var testModel = new Model("abc", new Map(), "#000000", "#000000");
    testModel.createFinalText(0, 0, "", new Map(), testModel.map);
    var result = testModel.getFinalText();
    if (result !== expected) {
        results.bad++;
        console.log("Expected " + expected +
        ", but was " + result);
    }
}

//Test for creating the finalText when we are given text with a space
function createTextTest4(expected) {
    results.total++;
    var testModel = new Model("abc def", new Map(), "#000000", "#000000");
    testModel.createFinalText(0, 0, "", new Map(), testModel.map);
    var result = testModel.getFinalText();
    if (result !== expected) {
        results.bad++;
        console.log("Expected " + expected +
        ", but was " + result);
    }
}

//Testing the bbCode making method
function bbTextTest1(expected) {
   results.total++;
   var testModel1 = new Model("", new Map(), "#0000ff", "#ff0000");
   var fixedString = testModel1.makeBbCode("mumps", "java");
   var testModel = new Model(fixedString, new Map(), "#000000", "#000000");
   testModel.createFinalText(0, 0, "", new Map(), testModel.map);
   var result = testModel.getFinalText();
   if (result !== expected) {
       results.bad++;
       console.log("Expected " + expected +
       ", but was " + result);
    }
}

//Creating a basic map and then trying to get outputs from it
function mapTest1(expected) {
	results.total++;
    var map1 = new Map();
    map1.addDictTerms(new DictTerm(["your"]), new DictTerm(["just"]));
    map1.addDictTerms(new DictTerm(["a"]), new DictTerm(["kidding"]));
    map1.addDictTerms(new DictTerm(["butt"]), new DictTerm(["xd"]));
    var phrase = "";
    mapToUse1 = map1.getOutput("your", 0);
    mapToUse2 = map1.getOutput("a", 0);
    mapToUse3 = map1.getOutput("butt", 0);
    phrase += (mapToUse1.output[0].term() + ".");
	phrase += (mapToUse2.output[0].term() + ".");
    phrase += mapToUse3.output[0].term();
    var testModel = new Model(phrase, map1, "#000000", "#000000");
    testModel.createFinalText(0, 0, "", new Map(), testModel.map);
    var result = testModel.getFinalText();
	if(result !== expected) {
       results.bad++;
       console.log("Expected " + expected +
       ", but was " + result);
	}
	
}

//Creating a map and then trying to get outputs for an invalid input
function mapTest2(expected) {
	results.total++;
    var map1 = new Map();
    map1.addDictTerms(new DictTerm(["1"]), new DictTerm(["Robbie Rotten"]));
    var phrase = "...";
    mapToUse1 = map1.getOutput("2", 0);
    phrase = mapToUse1.input[0];
	var result;
	if(phrase != "undefined") {
		result = "SIKE, THAT'S THE WRONG NUMBER";
	}
	if(result !== expected) {
       results.bad++;
       console.log("Expected " + expected +
       ", but was " + result);
	}
}

//Create the final text with a basic map
function correctionTest1(expected) {
	results.total++;
	var map = new Map();
    map.addDictTerms(new DictTerm(["energy"]), new DictTerm(["energy"]));
    map.addDictTerms(new DictTerm(["ball"]), new DictTerm(["ball"]));
    map.addDictTerms(new DictTerm(["Jellicent"]), new DictTerm(["Jellicent"]));
    var testModel = new Model("The quick brown fox jumps over the lazy dog", map, "#0000ff", "#ff0000");
    testModel.createFinalText(0, 0, "", new Map(), testModel.map);
    var result = testModel.getFinalText();
    if(result !== expected) {
        results.bad++;
        console.log("Expected " + expected +
        ", but was " + result);
	}
}

//Create the final text with map whose output dictTerms
//have multiple words
function correctionTest2(expected) {
	results.total++;
    var map = new Map();
    map.addDictTerms(new DictTerm(["cg"]), new DictTerm(["coconut", "gun"]));
    map.addDictTerms(new DictTerm(["dddd"]), new DictTerm (["donkey", "donkey", "donkey", "donkey"]));
    var testModel = new Model("The quick brown fox jumps over the lazy dog", map, "#0000ff", "#ff0000");
    testModel.createFinalText(0, 0, "", new Map(), testModel.map);
    var result = testModel.getFinalText();
    if(result !== expected) {
        results.bad++;
        console.log("Expected " + expected +
        ", but was " + result);
	}
}

//Test using maps like the old dictionaries
function correctionTest3(expected) {
	results.total++;
    var map = new Map();
    map.addDictTerms(new DictTerm(["skilled"]), new DictTerm(["skilled"]));
    map.addDictTerms(new DictTerm(["roy"]), new DictTerm(["roy"]));
    map.addDictTerms(new DictTerm(["any"]), new DictTerm(["any"]));
    map.addDictTerms(new DictTerm(["fox"]), new DictTerm(["fox"]));
    map.addDictTerms(new DictTerm(["sheik"]), new DictTerm(["fox"]));
    map.addDictTerms(new DictTerm(["peach"]), new DictTerm(["fox"]));
    map.addDictTerms(new DictTerm(["captain", "falcon"]), new DictTerm(["fox"]));
    var testModel = new Model("The quick brown fox jumps over the lazy dog", map, "#0000ff", "#ff0000");
    testModel.createFinalText(0, 0, "", new Map(), testModel.map);
    var result = testModel.getFinalText();
    if(result !== expected) {
        results.bad++;
        console.log("Expected " + expected +
        ", but was " + result);
    }
}

//simple test with a map acting like a dict
function correctionTest4(expected) {
	results.total++;
    var map = new Map();
    map.addDictTerms(new DictTerm(["fox"]), new DictTerm(["fox"]));
	var testModel = new Model("The quick brown Fox jumps over the lazy dog", map, "#0000ff", "#ff0000");
    testModel.createFinalText(0, 0, "", new Map(), testModel.map);
    var result = testModel.getFinalText();
    if(result !== expected) {
        results.bad++;
        console.log("Expected " +expected +
        ", but was " + result);
    }
}

//test with multiple corrections being made
function correctionTest5(expected) {
	results.total++;
    var map = new Map();
    map.addDictTerms(new DictTerm(["fox"]), new DictTerm(["fox"]));
    map.addDictTerms(new DictTerm(["dog"]), new DictTerm(["dog"]));
    map.addDictTerms(new DictTerm(["cat"]), new DictTerm(["cat"]));
	var testModel = new Model("The quick brown FoX jumps over the lazy DoG", map, "#0000ff", "#ff0000");
    testModel.createFinalText(0, 0, "", new Map(), testModel.map);
    var result = testModel.getFinalText();
    if(result !== expected) {
        results.bad++;
        console.log("Expected " +expected +
        ", but was " +result);
    }
}

//testing to make corrections at the end of the given text
function correctionTest6(expected) {
	results.total++;
	var map = new Map();
    map.addDictTerms(new DictTerm(["viable"]), new DictTerm(["not", "viable"]));
	var testModel = new Model("Roy is viable", map, "#0000ff", "#ff0000");
    testModel.createFinalText(0, 0, "", new Map(), testModel.map);
    var result = testModel.getFinalText();
    if(result !== expected) {
        results.bad++;
        console.log("Expected " +expected +
        ", but was " +result);
    }
}

//Another simple test of various corrections
function correctionTest7(expected) {
	results.total++;
	var map = new Map();
    map.addDictTerms(new DictTerm(["viable"]), new DictTerm(["not",  "viable"]));
    map.addDictTerms(new DictTerm(["Roy"]), new DictTerm(["Roy"]));
	var testModel = new Model("ROY is viable", map, "#0000ff", "#ff0000");
    testModel.createFinalText(0, 0, "", new Map(), testModel.map);
    var result = testModel.getFinalText();
    if(result !== expected) {
        results.bad++;
        console.log("Expected " + expected +
        ", but was " + result);
    }
}

//Tests for the DictTerm
function dictTest() {
    var dict1 = new DictTerm(["ban", "fox"]);
    var dict2 = new DictTerm(["i", "need", "scissors", "sixty", "one"]);
    var dict3 = new DictTerm([]);

    if (dict1.term() == "ban fox") {
        results.total++;
    }
    else {
        results.total++;
        results.bad++;
        console.log("Expected ban fox, but was " + dict1.term());
    }
    if (dict1.length() == 2) {
        results.total++;
    }
    else {
        results.total++;
        results.bad++;
        console.log("Expected 2, but was " + dict1.length());
    }
    if (dict2.term() == "i need scissors sixty one") {
        results.total++;
    }
    else {
        results.total++;
        results.bad++;
        console.log("Expected i need scisors sixty one, but was " + dict2.term());
    }
    if (dict2.length() == 5) {
        results.total++;
    }
    else {
        results.total++;
        results.bad++;
        console.log("Expected 5, but was " + dict2.length());
    }
    if (dict3.term() == "") {
        results.total++;
    }
    else {
        results.total++;
        results.bad++;
        console.log("Expected , but was " + dict3.term());
    }
    if (dict3.length() == 0) {
        results.total++;
    }
    else {
        results.total++;
        results.bad++;
        console.log("Expected 0, but was " + dict3.length());
    }

}

//Check to see if the current map adds terms correctly
function mapAddTermsTest() {
    var map1 = new Map();
    if (map1.input.length == 0) {
        results.total++;
    }
    else {
        results.total++;
        results.bad++;
        console.log("Expected input length 0, got length " + map1.input.length);
    }
    if (map1.output.length == 0) {
        results.total++;
    }
    else {
        results.total++;
        results.bad++;
        console.log("Expected input length 0, got length " + map1.input.length);
    }

    map1.addDictTerms(new DictTerm(["hi"]), new DictTerm(["bye"]));

    if (map1.input.length == 1) {
        results.total++;
    }
    else {
        results.total++;
        results.bad++;
        console.log("Expected input length 1, got length " + map1.input.length);
    }
    if (map1.output.length == 1) {
        results.total++;
    }
    else {
        results.total++;
        results.bad++;
        console.log("Expected input length 1, got length " + map1.input.length);
    }

    map1.addDictTerms(new DictTerm(["hey", "everyone"]), new DictTerm(["ban", "fox"]));

    if (map1.input.length == 2) {
        results.total++;
    }
    else {
        results.total++;
        results.bad++;
        console.log("Expected input length 2, got length " + map1.input.length);
    }
    if (map1.output.length == 2) {
        results.total++;
    }
    else {
        results.total++;
        results.bad++;
        console.log("Expected input length 2, got length " + map1.input.length);
    }
};

function mapOutputTest1() {
    var map = new Map();
    var outMap1 = map.getOutput("hi", 0);
    if (outMap1.input.length == 0 && outMap1.output.length == 0) {
        results.total++;
    }
    else {
        results.total++;
        results.bad++;
        console.log("Expected lengths 0, got input length " + map1.input.length + " and output length " + map1.output.length);
    }
    map.addDictTerms(new DictTerm(["hi"]), new DictTerm(["bye"]));
    outMap1 = map.getOutput("bye", 0);
    if (outMap1.input.length == 0 && outMap1.output.length == 0) {
        results.total++;
    }
    else {
        results.total++;
        results.bad++;
        console.log("Expected lengths 0, got input length " + map1.input.length + " and output length " + map1.output.length);
    }
    outMap1 = map.getOutput("hi", 1);
    if (outMap1.input.length == 0 && outMap1.output.length == 0) {
        results.total++;
    }
    else {
        results.total++;
        results.bad++;
        console.log("Expected lengths 0, got input length " + map1.input.length + " and output length " + map1.output.length);
    }
    outMap1 = map.getOutput("hi", 0);
    if (outMap1.input.length == 1 && outMap1.output.length == 1) {
        results.total++;
    }
    else {
        results.total++;
        results.bad++;
        console.log("Expected lengths 0, got input length " + map1.input.length + " and output length " + map1.output.length);
    }

};

function mapCloseTest() {

};

var results = {
    total: 0,
    bad: 0
};

function RunAllTests() {
    getFinalTextTest1("");
    createTextTest1(""); 
    createTextTest2("a");
    createTextTest3("abc");  
    createTextTest4("abc def");
    bbTextTest1("[B][COLOR=#ff0000][S]mumps[/S][/COLOR][/B] [B][COLOR=#0000ff]java[/COLOR][/B]");
    mapTest1("just.kidding.xd");
    mapTest2("SIKE, THAT'S THE WRONG NUMBER");
    correctionTest1("The quick brown fox jumps over the lazy dog");
    correctionTest2("The quick brown fox jumps over the lazy dog");
    correctionTest3("The quick brown fox jumps over the lazy dog");
    correctionTest4("The quick brown [B][COLOR=#ff0000][S]Fox[/S][/COLOR][/B] " +
				  "[B][COLOR=#0000ff]fox[/COLOR][/B] jumps over the lazy dog");
    correctionTest5("The quick brown [B][COLOR=#ff0000][S]FoX[/S][/COLOR][/B] " +
				  "[B][COLOR=#0000ff]fox[/COLOR][/B] jumps over the lazy " +
				  "[B][COLOR=#ff0000][S]DoG[/S][/COLOR][/B] [B][COLOR=#0000ff]dog[/COLOR][/B]");
    correctionTest6("Roy is [B][COLOR=#ff0000][S]viable[/S][/COLOR][/B] [B][COLOR=#0000ff]not viable[/COLOR][/B]");
    correctionTest7("[B][COLOR=#ff0000][S]ROY[/S][/COLOR][/B] [B][COLOR=#0000ff]Roy[/COLOR][/B] " +
        "is [B][COLOR=#ff0000][S]viable[/S][/COLOR][/B] [B][COLOR=#0000ff]not viable[/COLOR][/B]");
    dictTest();
    mapAddTermsTest();
    mapOutputTest1();
    

    console.log("Of " + results.total + " tests, " +
        results.bad + " failed, " +
        (results.total - results.bad) + " passed.");

}



