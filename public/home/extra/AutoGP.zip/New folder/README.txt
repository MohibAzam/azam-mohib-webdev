AutoGP v0.1 (2/3/17)

0. License Info
I'll figure this out later, but I anticipate this being a thing...

1. Introductory information
AutoGP is a tool currently tailored for Smogon C&C usage to expedite the GP process. It does so by 
checking through a given analysis or article for basic issues in accordance to the GP guidelines. It can 
identify these changes and will output the text with corrections in BBCode, ala a GP Analysis.

2. Usage
If you're using the .zip version, make sure you extract the .zip first. Next, click on the .html file. 
To use the app, paste whatever text you want to be checked to the lefthand textbox. Ideally, if you're 
pasting from a Smogon post, you should paste from the BBCode editor rather than the Rich Text Editor. 
To edit what colors will be used for making the BBCode corrections, click on the color buttons and adjust 
them as needed. When you're done, click the button "run the checker" and the result will be outputted 
into the righthand box. Copy this and then paste into the BBCode editor when editing a post, then 
switch back to rich text and you should have your proper output. 
The radio buttons for Analysis Vs Article will not do anything at the moment.

3. What it checks for
AutoGP is currently hardcoded to check for specific incorrect terms (namely those found in Aberforth's 
Lunala analysis�sorry for being the test subject :///). It will check if the following terms don't have 
proper capitalization: "sleep", "Speed", "status". It will also convert any forms of "Ekiller" to "Extreme 
Killer Arceus", "max" to "maximum", "rocks" to "Stealth Rock", "Luke" to "Lucario", "Fairceus" to 
"Arceus-Fairy", and "ZHypnosis" to "Z-Hypnosis".
The way it is currently set up, it unfortunately can only check one word at a time. I intend to introduce 
JSON files or something similar to store the required information of what to check for, which should 
prevent the need of hardcode, make the checking system more flexible, and also allow for multiple 
words to be checked should I adjust the program as needed.

4. Version History
v 0.1 (2/3/17): Alpha version

5. Future Additions
1. Add JSON file reading
2. Add handling for multiple words
** BETA VERSION **
3. Clean up the code as needed 
4. Fix CSS as needed
5. Give functionality to the Radio Buttons
** 1.0 **
6. Add true spellchecking and grammar checking functionality

6. Credits
Created by Mr. Uncompetitive
Special Thanks 
-	Lemonade for consultation
-	Rest of the GP Server members (Talkingtree, Rare Poison, Hulavuta, Kris, fleurdyleruse, 
P_Squared etc.) for their support
